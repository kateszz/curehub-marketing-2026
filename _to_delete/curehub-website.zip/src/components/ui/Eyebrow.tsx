import { cn } from "@/lib/utils";

/** Small uppercase label used above section headings (e.g. "OUR PRODUCT"). */
export function Eyebrow({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-sm rounded-full border border-current/20 px-md py-xs font-display text-body-sm uppercase tracking-[0.08em] text-brand-600",
        className
      )}
    >
      {children}
    </span>
  );
}
